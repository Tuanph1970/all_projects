from typing import Any

from vnai import optimize_execution

from vnstock.ui._base import BaseDetailUI


class ForexMarket(BaseDetailUI):
    """Forex market data."""

    @optimize_execution("UI")
    def ohlcv(
        self,
        start: str = None,
        end: str = None,
        interval: str = "1D",
        count: int = 100,
        source: str = "msn",
        **kwargs,
    ) -> Any:
        """Historical OHLCV bars for forex pairs."""
        # Handle parameter aliases
        interval = kwargs.pop("resolution", interval)
        count_back = kwargs.pop("length", count)
        return self._dispatch(
            "Market",
            "forex",
            "ohlcv",
            start=start,
            end=end,
            interval=interval,
            count_back=count_back,
            source=source,
            **kwargs,
        )
